﻿namespace MVCIntro2023.Models
{
    public class DonutOrderContext
    {
        public static List<DonutOrder> donutOrders= new List<DonutOrder>();
    }
}
