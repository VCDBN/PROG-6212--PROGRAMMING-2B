﻿namespace MVCIntro2023.Models
{
    public class DonutOrder
    {
        public int OrderID {  get; set; }

        public string Name { get; set; }
        public int QtyDonuts { get; set; }
        public int QtyCoffee { get; set; }


        public DonutOrder(int orderID, string name, int qtyDonuts, int qtyCoffee)
        {
            OrderID = orderID;
            Name = name;
            QtyDonuts = qtyDonuts;
            QtyCoffee = qtyCoffee;
        }   
    }
}
