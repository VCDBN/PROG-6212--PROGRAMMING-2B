﻿using Microsoft.AspNetCore.Mvc;
using MVCIntro2023.Models; 


namespace MVCIntro2023.Controllers
{
    public class DonutController : Controller
    {

        public DonutController() {
            if (DonutOrderContext.donutOrders.Count <= 0)
            {
                Models.DonutOrderContext.donutOrders.Add(new DonutOrder(0, "Denz", 4, 4));//index 0
                Models.DonutOrderContext.donutOrders.Add(new DonutOrder(1, "John", 5, 5));//index 1

            }

        }
        public IActionResult Index()
        {

            List<DonutOrder> donuts = DonutOrderContext.donutOrders;

            ViewBag.Discount = "10%";
            return View();
        }

        // public IActionResult ShowDonut()
        // {  
        //     return View(DonutOrderContext.donutOrders[0]);
        //  }
        //This is changing
        public IActionResult ShowDonut(int id)
        {
            DonutOrder donut = DonutOrderContext.donutOrders.Where(d => d.OrderID == id).Single();
            return View(donut);
            //you should normally implement exception handling here
        }

        public IActionResult ShowAllDonuts()// you need to go create this view Razor view/ list/select model
        {
            return View(DonutOrderContext.donutOrders);
        }


    
        public IActionResult CreateDonut()// you need to go create this view Razor View/Create/Select model
        {
            return View();
        }
     


        [HttpPost]
        public IActionResult CreateDonut(int OrderID,string Name,int QtyDonuts, int QtyCoffee)
            
        
        {
            DonutOrderContext.donutOrders.Add(new DonutOrder(OrderID,Name,QtyDonuts,QtyCoffee));

            return RedirectToAction("ShowAllDonuts","Donut");

           
            //if(OrderID == 0 || Name == null || QtyCoffee <=0 || QtyDonuts <=0) {
            //    ViewBag.error = "Check your Data";
            //    return View();
            
            }
           

        }


    }

