var builder = WebApplication.CreateBuilder(args);

// Add services to the container.
builder.Services.AddControllersWithViews();

var app = builder.Build();

// Configure the HTTP request pipeline.
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Home/Error");
    // The default HSTS value is 30 days. You may want to change this for production scenarios, see https://aka.ms/aspnetcore-hsts.
    app.UseHsts();
}

app.UseHttpsRedirection();
// this will redirect your requests to the equivalent HTTPS counterparts

app.UseStaticFiles();
// Enables the serving or static files such as images, CSS,files etc from the web server

app.UseRouting();// this handles the routing within the application. Matches incoming requests
//to the apporpriate handlers

app.UseAuthorization();
//This enables the application to perform authorization checks for incoming requests


//Here you are setting u the route to the application. Inthis case you can see controller Home
app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Home}/{action=Index}/{id?}");

app.Run();
