﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using MVCAppLat8.Models;

namespace MVCAppLat8.Controllers
{
    public class TargetSalesController : Controller
    {
        private readonly DBTargetsales _context;

        public TargetSalesController(DBTargetsales context)
        {
            _context = context;
        }

        // GET: TargetSales
        public async Task<IActionResult> Index()
        {
            return View(await _context.TargetSales.ToListAsync());
        }

        // GET: TargetSales/Details/5
        public async Task<IActionResult> Details(string id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var targetSale = await _context.TargetSales
                .FirstOrDefaultAsync(m => m.AgentName == id);
            if (targetSale == null)
            {
                return NotFound();
            }

            return View(targetSale);
        }

        // GET: TargetSales/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: TargetSales/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("AgentName,AgentSales")] TargetSale targetSale)
        {
            if (ModelState.IsValid)
            {
                _context.Add(targetSale);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(targetSale);
        }

        // GET: TargetSales/Edit/5
        public async Task<IActionResult> Edit(string id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var targetSale = await _context.TargetSales.FindAsync(id);
            if (targetSale == null)
            {
                return NotFound();
            }
            return View(targetSale);
        }

        // POST: TargetSales/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(string id, [Bind("AgentName,AgentSales")] TargetSale targetSale)
        {
            if (id != targetSale.AgentName)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(targetSale);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!TargetSaleExists(targetSale.AgentName))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(targetSale);
        }

        // GET: TargetSales/Delete/5
        public async Task<IActionResult> Delete(string id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var targetSale = await _context.TargetSales
                .FirstOrDefaultAsync(m => m.AgentName == id);
            if (targetSale == null)
            {
                return NotFound();
            }

            return View(targetSale);
        }

        // POST: TargetSales/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(string id)
        {
            var targetSale = await _context.TargetSales.FindAsync(id);
            if (targetSale != null)
            {
                _context.TargetSales.Remove(targetSale);
            }

            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool TargetSaleExists(string id)
        {
            return _context.TargetSales.Any(e => e.AgentName == id);
        }

     

    }
}
