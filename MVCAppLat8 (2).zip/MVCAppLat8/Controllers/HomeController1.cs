﻿using Microsoft.AspNetCore.Mvc;
using MVCAppLat8.Models;

namespace MVCAppLat8.Controllers
{
    public class HomeController1 : Controller
    {
        public IActionResult View1()
        {
            var agentSales = GetMockAgentSalesData();
            return View(agentSales);
        }
        private List<AgentSale> GetMockAgentSalesData()
        {
            // Create mock data
            var agentSales = new List<AgentSale>
        {
            new AgentSale { AgentName = "Agent 1", AgentSales = 200 },
            new AgentSale { AgentName = "Agent 2", AgentSales = 300 },
            new AgentSale { AgentName = "Agent 3", AgentSales = 150 },
            // Add more data as needed
        };
            return agentSales;
        }
    }
}
