using MVCAppLat8.Models;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.
builder.Services.AddControllersWithViews();

//Add this additional service here- ApplicationName.Models.ModelName
builder.Services.AddDbContext<MVCAppLat8.Models.DBTargetsales>();

var app = builder.Build();

if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Home/Error");
    app.UseHsts();
}

app.UseHttpsRedirection();
app.UseStaticFiles();
app.UseRouting();
app.UseAuthorization();
app.MapControllerRoute(

    name: "default",
    pattern: "{controller=TargetSales}/{action=Index}/{id?}");
//Change to setup your startup page
app.Run();
