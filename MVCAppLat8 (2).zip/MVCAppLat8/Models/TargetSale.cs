﻿using System;
using System.Collections.Generic;

namespace MVCAppLat8.Models;

public partial class TargetSale
{
    public string AgentName { get; set; } = null!;

    public int AgentSales { get; set; }
}
