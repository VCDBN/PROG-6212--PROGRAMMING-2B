﻿namespace MVCAppLat8.Models
{
    public class AgentSale
    {
        public string AgentName { get; set; }
        public int AgentSales { get; set; }
    }
}
